const express = require('express');
const app = express();
app.use(express.json());

let products = [
    { id: '1', name: 'Product 1', price: 100 },
    { id: '2', name: 'Product 2', price: 200 }
];

let orders = [];

app.get('/api/products', (req, res) => res.json(products));

app.post('/api/orders', (req, res) => {
    orders.push(req.body.items);
    res.json({ status: 'Order placed' });
});

app.listen(3000, () => console.log('Backend running on port 3000'));